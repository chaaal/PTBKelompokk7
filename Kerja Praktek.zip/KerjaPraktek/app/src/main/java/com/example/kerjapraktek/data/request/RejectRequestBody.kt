package com.example.kerjapraktek.data.request

data class RejectRequestBody(
    val reason: String
)
