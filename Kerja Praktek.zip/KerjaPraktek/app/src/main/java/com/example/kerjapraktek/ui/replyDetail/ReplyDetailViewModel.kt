package com.example.kerjapraktek.ui.replyDetail

import androidx.lifecycle.ViewModel
import com.example.kerjapraktek.data.UserRepository

class ReplyDetailViewModel(private val repository: UserRepository) : ViewModel() {
}