package com.example.kerjapraktek.data.pref

data class UserModel(
    val token: String,
    val isLogin: Boolean = false
)