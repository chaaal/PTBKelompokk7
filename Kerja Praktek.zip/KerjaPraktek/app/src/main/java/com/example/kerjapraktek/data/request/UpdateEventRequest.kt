package com.example.kerjapraktek.data.request

data class UpdateEventRequest(
    val eventDate: String,
    val location: String
)