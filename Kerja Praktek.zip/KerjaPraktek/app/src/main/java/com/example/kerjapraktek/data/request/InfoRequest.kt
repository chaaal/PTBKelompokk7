package com.example.kerjapraktek.data.request

class InfoRequest (
    val title: String,
    val description: String
)

